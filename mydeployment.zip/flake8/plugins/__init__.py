"""Submodule of built-in plugins and plugin managers."""
from __future__ import annotations
